import asyncio
import aiohttp
import logging

logger = logging.getLogger("GroupCheckInBot")

_session = None  # 全局 Session


def get_session():
    """获取或创建全局 aiohttp ClientSession"""
    global _session
    if _session is None or _session.closed:
        _session = aiohttp.ClientSession()
    return _session


async def close_session():
    """关闭全局 aiohttp ClientSession"""
    global _session
    try:
        if _session and not _session.closed:
            await _session.close()
            logger.info("✅ [tasks] aiohttp ClientSession 已关闭")
    except Exception as e:
        logger.warning(f"⚠️ [tasks] 关闭 session 出错: {e}")


async def perform_checkin_once():
    """执行一次打卡"""
    session = get_session()
    try:
        logger.info("🕒 正在执行打卡任务（示例）...")
        async with session.get("https://example.com/checkin") as resp:
            data = await resp.text()
            logger.info(f"打卡结果: HTTP {resp.status}, 内容: {data[:100]}")
    except Exception as e:
        logger.error(f"打卡请求出错: {e}")


async def start_auto_checkin_loop():
    """后台自动打卡循环任务"""
    logger.info("🕒 自动打卡循环任务已启动")
    while True:
        try:
            await perform_checkin_once()
        except Exception as e:
            logger.error(f"打卡错误: {e}")
        await asyncio.sleep(3600)
