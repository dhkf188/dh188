import asyncio
import json
import os
import csv
from datetime import datetime, timedelta
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram.filters import CommandObject
from aiogram.types import (
    ReplyKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardRemove,
    FSInputFile
)
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage

import aiofiles
import logging

# 日志配置
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

save_lock = asyncio.Lock()
save_pending = False

async def async_save_data():
    """异步保存群组数据"""
    global save_pending
    async with save_lock:
        try:
            async with aiofiles.open(config.DATA_FILE, "w", encoding="utf-8") as f:
                await f.write(json.dumps(group_data, ensure_ascii=False, indent=2))
            save_pending = False
            logging.info("✅ 异步保存 group_data 完成")
        except Exception as e:
            logging.error(f"❌ 异步保存失败: {e}")

async def schedule_save_data():
    """延迟保存，避免频繁I/O"""
    global save_pending
    if not save_pending:
        save_pending = True
        await asyncio.sleep(3)
        await async_save_data()

# 删除重复的 save_data 函数定义


# ==================== 集中配置区域 ====================
class Config:
    # Bot 配置
    TOKEN = "8150090742:AAGBp_s3yIkyzElpCDcDjjUDPnn8quwOuqU"  # 替换为你的Bot Token

    # 文件配置
    DATA_FILE = "group_data.json"
    ACTIVITY_FILE = "activities.json"
    PUSH_SETTINGS_FILE = "push_settings.json"

    # 管理员配置
    ADMINS = [8356418002, 87654321]  # 替换成管理员 Telegram ID 列表

    # 默认活动配置
    DEFAULT_ACTIVITY_LIMITS = {
        "吃饭": {"max_times": 2, "time_limit": 30},
        "小厕": {"max_times": 5, "time_limit": 5},
        "大厕": {"max_times": 2, "time_limit": 15},
        "抽烟": {"max_times": 5, "time_limit": 10},
    }

    # 默认罚款（如果没有为活动单独设置，会使用这里的默认）
    DEFAULT_FINE_RATES = {
        "吃饭": {"10": 100, "30": 300},
        "小厕": {"5": 50, "10": 100},
        "大厕": {"15": 80, "30": 200},
        "抽烟": {"10": 200, "30": 500},
    }

    # 自动导出推送开关配置
    AUTO_EXPORT_SETTINGS = {
        "enable_channel_push": True,    # 是否推送到频道
        "enable_group_push": True,      # 是否推送到通知群组
        "enable_admin_push": True,      # 是否推送到管理员（当没有绑定群组/频道时）
    }

    # 超时配置
    AUTO_BACK_MINUTES = 30  # 现在只用于提醒，不强制回座
    REMINDER_INTERVAL = 5

    # 每日重置时间配置（24小时制）
    DAILY_RESET_HOUR = 0    # 0点重置
    DAILY_RESET_MINUTE = 0  # 0分

    # 消息模板
    MESSAGES = {
        "welcome": "欢迎使用群打卡机器人！请点击下方按钮或直接输入活动名称打卡：",
        "no_activity": "❌ 没有找到正在进行的活动，请先打卡活动再回座。",
        "has_activity": "❌ 您当前有活动【{}】正在进行中，请先回座后才能开始新活动！",
        "no_permission": "❌ 你没有权限执行此操作",
        "max_times_reached": "❌ 您今日的{}次数已达到上限（{}次），无法再次打卡",
        "setchannel_usage": "❌ 用法：/setchannel <频道ID>\n频道ID格式如 -1001234567890",
        "setgroup_usage": "❌ 用法：/setgroup <群组ID>\n用于接收超时通知的群组ID",
        "set_usage": "❌ 用法：/set <用户ID> <活动> <时长分钟>",
        "reset_usage": "❌ 用法：/reset <用户ID>",
        "addactivity_usage": "❌ 用法：/addactivity <活动名> <max次数> <time_limit分钟>",
        "setresettime_usage": "❌ 用法：/setresettime <小时> <分钟>\n例如：/setresettime 0 0 表示每天0点重置",
        "setfine_usage": "❌ 用法：/setfine <活动名> <时间段> <金额>\n例如：/setfine 抽烟 10 200",
        "setfines_all_usage": "❌ 用法：/setfines_all <t1> <f1> [<t2> <f2> ...]\n例如：/setfines_all 10 100 30 300 60 1000",
        "setpush_usage": "❌ 用法：/setpush <channel|group|admin> <on|off>"
    }

# ==================== 状态机类 ====================
class AdminStates(StatesGroup):
    waiting_for_channel_id = State()
    waiting_for_group_id = State()

# ==================== 初始化配置 ====================
config = Config()
storage = MemoryStorage()

# 内存数据
group_data = {}
activity_limits = config.DEFAULT_ACTIVITY_LIMITS.copy()
fine_rates = config.DEFAULT_FINE_RATES.copy()  # 罚款费率（每活动字典）
# 也可能会在 setfines_all 时为所有活动统一覆盖
tasks = {}  # 定时任务：chat_id-uid → asyncio.Task

bot = Bot(token=config.TOKEN)
dp = Dispatcher(storage=storage)

# ==================== 工具函数 ====================
def format_time(seconds: int):
    """格式化时间显示"""
    m, s = divmod(seconds, 60)
    h, m = divmod(m, 60)
    if h > 0:
        return f"{h}小时{m}分钟"
    elif m > 0:
        return f"{m}分钟{s}秒"
    else:
        return f"{s}秒"

def format_time_for_export(seconds: int):
    """为导出数据格式化时间显示"""
    m, s = divmod(seconds, 60)
    h, m = divmod(m, 60)
    if h > 0:
        return f"{h}时{m}分{s}秒"
    elif m > 0:
        return f"{m}分{s}秒"
    else:
        return f"{s}秒"

def is_admin(uid):
    """检查用户是否为管理员"""
    return uid in config.ADMINS

def init_group(chat_id: int):
    """初始化群组数据"""
    if str(chat_id) not in group_data:
        group_data[str(chat_id)] = {
            "频道ID": None,
            "通知群组ID": None,
            "每日重置时间": {"hour": config.DAILY_RESET_HOUR, "minute": config.DAILY_RESET_MINUTE},
            "成员": {}
        }

def init_user(chat_id: int, uid: int):
    """初始化用户数据"""
    init_group(chat_id)
    if str(uid) not in group_data[str(chat_id)]["成员"]:
        group_data[str(chat_id)]["成员"][str(uid)] = {
            "活动": None,
            "开始时间": None,
            "累计": {},
            "次数": {},
            "最后更新": str(datetime.now().date()),
            "昵称": None,
            "用户ID": uid,
            "总累计时间": 0,
            "总次数": 0,
            "累计罚款": 0
        }

async def reset_daily_data(chat_id: int, uid: int):  # 改为 async
    """每日数据重置"""
    today = str(datetime.now().date())
    if group_data[str(chat_id)]["成员"][str(uid)]["最后更新"] != today:
        group_data[str(chat_id)]["成员"][str(uid)]["累计"] = {}
        group_data[str(chat_id)]["成员"][str(uid)]["次数"] = {}
        group_data[str(chat_id)]["成员"][str(uid)]["总累计时间"] = 0
        group_data[str(chat_id)]["成员"][str(uid)]["总次数"] = 0
        group_data[str(chat_id)]["成员"][str(uid)]["累计罚款"] = 0
        group_data[str(chat_id)]["成员"][str(uid)]["最后更新"] = today
        await schedule_save_data()


def check_activity_limit(chat_id: int, uid: int, act: str):
    """检查活动次数是否达到上限"""
    init_user(chat_id, uid)
    # 这里需要改为异步调用
    # reset_daily_data(chat_id, uid)  # ❌ 原来的调用
    # 由于这个函数是同步的，需要在调用处处理异步
    
    current_count = group_data[str(chat_id)]["成员"][str(uid)]["次数"].get(act, 0)
    max_times = activity_limits[act]["max_times"]

    return current_count < max_times, current_count, max_times

def has_active_activity(chat_id: int, uid: int):
    """检查用户是否有活动正在进行"""
    init_user(chat_id, uid)
    user_data = group_data[str(chat_id)]["成员"][str(uid)]
    return user_data["活动"] is not None, user_data["活动"]

def load_data():
    """加载数据文件"""
    global group_data, activity_limits, fine_rates
    if os.path.exists(config.DATA_FILE):
        with open(config.DATA_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            # 兼容旧版本数据
            for chat_id, chat_data in data.items():
                if "每日重置时间" not in chat_data:
                    chat_data["每日重置时间"] = {"hour": config.DAILY_RESET_HOUR, "minute": config.DAILY_RESET_MINUTE}
            group_data = data

    if os.path.exists(config.ACTIVITY_FILE):
        with open(config.ACTIVITY_FILE, "r", encoding="utf-8") as f:
            activity_data = json.load(f)
            # 兼容旧版本数据格式
            if isinstance(activity_data, dict) and "activities" in activity_data:
                activity_limits = activity_data.get("activities", config.DEFAULT_ACTIVITY_LIMITS.copy())
                fine_rates = activity_data.get("fines", config.DEFAULT_FINE_RATES.copy())
            else:
                activity_limits = activity_data
                fine_rates = config.DEFAULT_FINE_RATES.copy()

def save_data():  # ✅ 移除 await
    """保存数据到文件"""
    with open(config.DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(group_data, f, ensure_ascii=False, indent=2, default=str)

    # 保存活动配置和罚款配置
    activity_data = {
        "activities": activity_limits,
        "fines": fine_rates
    }
    with open(config.ACTIVITY_FILE, "w", encoding="utf-8") as f:
        json.dump(activity_data, f, ensure_ascii=False, indent=2)

def save_push_settings():
    """保存推送设置到文件"""
    try:
        with open(config.PUSH_SETTINGS_FILE, "w", encoding="utf-8") as f:
            json.dump(config.AUTO_EXPORT_SETTINGS, f, ensure_ascii=False, indent=2)
        print("✅ 推送设置已保存")
    except Exception as e:
        print(f"❌ 保存推送设置失败：{e}")

def load_push_settings():
    """从文件加载推送设置"""
    try:
        if os.path.exists(config.PUSH_SETTINGS_FILE):
            with open(config.PUSH_SETTINGS_FILE, "r", encoding="utf-8") as f:
                saved_settings = json.load(f)
                # 更新配置，但保留默认值以防文件缺少某些设置
                for key, value in saved_settings.items():
                    if key in config.AUTO_EXPORT_SETTINGS:
                        config.AUTO_EXPORT_SETTINGS[key] = value
            print("✅ 推送设置已加载")
    except Exception as e:
        print(f"❌ 加载推送设置失败：{e}")

async def send_to_channel(chat_id: int, text: str):
    """发送消息到绑定频道"""
    channel_id = group_data.get(str(chat_id), {}).get("频道ID")
    if channel_id:
        try:
            await bot.send_message(channel_id, text, parse_mode="HTML")
        except Exception:
            pass

async def send_to_notification_group(chat_id: int, text: str):
    """发送消息到通知群组"""
    notification_group_id = group_data.get(str(chat_id), {}).get("通知群组ID")
    if notification_group_id:
        try:
            await bot.send_message(notification_group_id, text, parse_mode="HTML")
        except Exception:
            pass

async def send_all_notifications(chat_id: int, text: str):
    """发送到所有通知渠道"""
    await send_to_channel(chat_id, text)
    await send_to_notification_group(chat_id, text)

def calculate_fine(activity: str, overtime_minutes: float) -> int:
    """计算罚款金额 - 分段罚款"""
    # 优先使用活动自己的 fine_rates，如果没有使用全局默认
    if activity not in fine_rates:
        # 找到某个默认（取Config.DEFAULT_FINE_RATES中的同名或全局最后一段）
        return 0

    fine_segments = fine_rates[activity]
    # 将时间段转换为整数并排序
    segments = sorted([int(time) for time in fine_segments.keys()])

    # 找到适用的罚款段
    applicable_fine = 0
    for segment in segments:
        if overtime_minutes <= segment:
            applicable_fine = fine_segments[str(segment)]
            break

    # 如果超过所有段，使用最后一个段的罚款
    if applicable_fine == 0 and segments:
        applicable_fine = fine_segments[str(segments[-1])]

    return applicable_fine

# ==================== 格式化消息函数 ====================
def format_user_link(user_id: int, user_name: str):
    """格式化用户链接（可点击联系）"""
    # 清理用户名中的特殊字符
    if not user_name:
        user_name = f"用户{user_id}"
    clean_name = str(user_name).replace('<', '').replace('>', '').replace('&', '').replace('"', '')
    return f'<a href="tg://user?id={user_id}">{clean_name}</a>'

def create_dashed_line() -> str:
    """创建短虚线分割线"""
    return "--------------------------------------------"

def format_copyable_text(text: str) -> str:
    """格式化可复制文本"""
    return f"<code>{text}</code>"

def format_activity_message(user_id: int, user_name: str, activity: str, time_str: str,
                           count: int, max_times: int, time_limit: int):
    """格式化打卡消息"""
    first_line = f"👤 用户：{format_user_link(user_id, user_name)}"

    message = (
        f"{first_line}\n"
        f"✅ 打卡成功：{format_copyable_text(activity)} - {format_copyable_text(time_str)}\n"
        f"⚠️ 注意：这是您第 {format_copyable_text(str(count))} 次{format_copyable_text(activity)}（今日上限：{format_copyable_text(str(max_times))}次）\n"
        f"⏰ 本次活动时间限制：{format_copyable_text(str(time_limit))} 分钟"
    )

    if count >= max_times:
        message += f"\n⚠️ 警告：本次结束后，您今日的{format_copyable_text(activity)}次数将达到上限，请留意！"

    message += f"\n💡提示：活动完成后请及时输入'回座'或点击'✅ 回座'按钮"

    return message

def format_back_message(user_id: int, user_name: str, activity: str, time_str: str, elapsed_time: str,
                       total_activity_time: str, total_time: str, activity_counts: dict, total_count: int,
                       is_overtime: bool = False, overtime_seconds: int = 0, fine_amount: int = 0):
    """格式化回座消息 - 按照指定格式"""
    first_line = f"👤 用户：{format_user_link(user_id, user_name)}"

    message = (
        f"{first_line}\n"
        f"✅ {format_copyable_text(time_str)} 回座打卡成功\n"
        f"📝 活动：{format_copyable_text(activity)}\n"
        f"⏱️ 本次活动耗时：{format_copyable_text(elapsed_time)}\n"
        f"📊 今日累计{format_copyable_text(activity)}时间：{format_copyable_text(total_activity_time)}\n"
        f"📈 今日总计时：{format_copyable_text(total_time)}\n"
    )

    if is_overtime:
        overtime_time = format_time(int(overtime_seconds))
        message += f"⚠️ 警告：您本次的活动已超时！\n超时时间：{format_copyable_text(overtime_time)}\n"
        if fine_amount > 0:
            message += f"罚款：{format_copyable_text(str(fine_amount))} 元\n"

    # 使用短虚线分割线
    dashed_line = create_dashed_line()
    message += f"{dashed_line}\n"

    for act, count in activity_counts.items():
        if count > 0:
            message += f"🔢 本日{format_copyable_text(act)}次数：{format_copyable_text(str(count))} 次\n"

    message += f"\n📊 今日总活动次数：{format_copyable_text(str(total_count))} 次"

    return message

def format_timeout_message(user_id: int, user_name: str, activity: str, over_time_minutes: int):
    """格式化超时提醒消息给群内用户"""
    first_line = f"👤 用户：{format_user_link(user_id, user_name)}"

    return (
        f"{first_line}\n"
        f"⚠️ 超时提醒：您的 {format_copyable_text(activity)} 已经超时 {format_copyable_text(str(over_time_minutes))} 分钟！请及时回座。"
    )

def format_warning_message(user_id: int, user_name: str, activity: str, message_type: str):
    """格式化警告消息（1分钟警告与超时警告）"""
    first_line = f"👤 用户：{format_user_link(user_id, user_name)}"
    if message_type == "1min_warning":
        return f"{first_line}\n⚠️ 警告：您本次{format_copyable_text(activity)}还有不到 1 分钟超时，请尽快回座！"
    elif message_type == "timeout":
        return f"{first_line}\n⚠️ 警告：您本次{format_copyable_text(activity)}已超时，请尽快回座！"
    return f"{first_line}\n⚠️ 警告消息"

async def format_timeout_notification(chat_id: int, user_ids: list, activity: str, status: str,
                                      overtime_seconds: int, fine_amount: int):
    """
    格式化超时通知，返回字符串。
    user_ids: list of tuples or list; usually [(uid, nickname), ...] or single
    """
    # 尝试获取群组名称
    try:
        chat = await bot.get_chat(chat_id)
        chat_title = chat.title or str(chat_id)
    except Exception:
        chat_title = str(chat_id)

    # 组装用户显示（支持多个用户）
    users_text = []
    for uid, nickname in user_ids:
        users_text.append(f"{nickname} {format_user_link(uid, nickname)}")
    users_line = "，".join(users_text)

    over_time_str = format_time(int(overtime_seconds)) if overtime_seconds else "0 秒"
    fine_str = f"{fine_amount}" if fine_amount else "0"

    # 模板（根据用户给定的样例）
    notif = (
        f"群组：{format_copyable_text(chat_title)}\n"
        f"用户：{users_line}\n"
        f"打卡活动：{format_copyable_text(activity)}\n"
        f"状态：{format_copyable_text(status)}\n"
        f"超时时长：{format_copyable_text(over_time_str)}\n"
        f"本次惩罚：{format_copyable_text(fine_str)}\n"
    )
    return notif

# ==================== 回复键盘（输入栏下方按钮） ====================
def get_main_keyboard(show_admin=False):
    """获取主回复键盘（显示在输入栏下方），活动按钮根据 activity_limits 动态生成"""
    # 动态活动按钮（每行最多3个）
    activity_buttons = []
    row = []
    for i, act in enumerate(activity_limits.keys(), 1):
        emoji_label = act  # 保留原始文字（你可以在这里添加 emoji 对应表）
        row.append(KeyboardButton(text=emoji_label))
        if len(row) >= 3:
            activity_buttons.append(row)
            row = []
    if row:
        activity_buttons.append(row)

    # 功能按钮布局
    function_buttons = []
    
    # 倒数第二行：管理员面板、我的记录、排行榜
    if show_admin:
        function_buttons.append([
            KeyboardButton(text="👑 管理员面板"),
            KeyboardButton(text="📊 我的记录"), 
            KeyboardButton(text="🏆 排行榜")
        ])
    else:
        function_buttons.append([
            KeyboardButton(text="📊 我的记录"), 
            KeyboardButton(text="🏆 排行榜")
        ])
    
    # 最后一行：回座按钮独占一行
    function_buttons.append([KeyboardButton(text="✅ 回座")])

    keyboard = activity_buttons + function_buttons

    return ReplyKeyboardMarkup(
        keyboard=keyboard,
        resize_keyboard=True,
        one_time_keyboard=False,
        input_field_placeholder="请选择操作或输入活动名称..."
    )

def get_admin_keyboard():
    """管理员专用键盘"""
    return ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(text="👑 管理员面板"),
                KeyboardButton(text="📤 导出数据")
            ],
            [
                KeyboardButton(text="🔔 通知设置")
            ],
            [
                KeyboardButton(text="🔙 返回主菜单")
            ]
        ],
        resize_keyboard=True
    )

# ==================== 活动定时提醒 ====================
async def activity_timer(chat_id: int, uid: int, act: str, limit: int):
    """活动定时提醒任务（优化版）"""
    try:
        key = f"{chat_id}-{uid}"
        user_data = group_data[str(chat_id)]["成员"][str(uid)]
        nickname = user_data.get('昵称', str(uid))

        # 防止重复任务
        existing = tasks.get(key)
        if existing and not existing.done():
            existing.cancel()

        # 一分钟前提醒
        await asyncio.sleep(limit * 60 - 60)
        if group_data[str(chat_id)]["成员"][str(uid)]["活动"] == act:
            await bot.send_message(chat_id, f"⚠️ {nickname} 的 {act} 还有1分钟到时！")

        # 超时循环提醒
        over_time = 0
        while group_data[str(chat_id)]["成员"][str(uid)]["活动"] == act:
            await asyncio.sleep(config.REMINDER_INTERVAL * 60)
            over_time += config.REMINDER_INTERVAL
            await bot.send_message(chat_id, f"⏰ {nickname} 的 {act} 已超时 {over_time} 分钟，请尽快回座。")

    except asyncio.CancelledError:
        pass
    except Exception as e:
        logging.error(f"定时器错误: {e}")


# ==================== 核心打卡功能 ====================
async def start_activity(message: types.Message, act: str):
    """开始活动打卡 - 增加次数上限检查和活动冲突检查"""
    chat_id = message.chat.id
    uid = message.from_user.id
    name = message.from_user.full_name
    now = datetime.now()

    # 检查活动是否存在
    if act not in activity_limits:
        await message.answer(
            f"❌ 活动 '{act}' 不存在，请使用下方按钮选择活动",
            reply_markup=get_main_keyboard(show_admin=is_admin(uid))
        )
        return

    # 检查是否有活动正在进行
    has_active, current_act = has_active_activity(chat_id, uid)
    if has_active:
        await message.answer(
            config.MESSAGES["has_activity"].format(current_act),
            reply_markup=get_main_keyboard(show_admin=is_admin(uid))
        )
        return

    # 初始化用户和重置每日数据
    init_user(chat_id, uid)
    await reset_daily_data(chat_id, uid)

    # 检查次数限制
    current_count = group_data[str(chat_id)]["成员"][str(uid)]["次数"].get(act, 0)
    max_times = activity_limits[act]["max_times"]
    can_start = current_count < max_times

    if not can_start:
        await message.answer(
            config.MESSAGES["max_times_reached"].format(act, max_times),
            reply_markup=get_main_keyboard(show_admin=is_admin(uid))
        )
        return

    # 更新用户数据
    group_data[str(chat_id)]["成员"][str(uid)]["昵称"] = name
    count = current_count + 1
    group_data[str(chat_id)]["成员"][str(uid)]["活动"] = act
    group_data[str(chat_id)]["成员"][str(uid)]["开始时间"] = str(now)
    group_data[str(chat_id)]["成员"][str(uid)]["次数"][act] = count
    await schedule_save_data()

    # 启动定时器
    key = f"{chat_id}-{uid}"
    if key in tasks and not tasks[key].done():
        tasks[key].cancel()
    tasks[key] = asyncio.create_task(activity_timer(chat_id, uid, act, activity_limits[act]["time_limit"]))

    # 构建回复消息
    await message.answer(
        format_activity_message(uid, name, act, now.strftime('%m/%d %H:%M:%S'),
                                count, max_times, activity_limits[act]["time_limit"]),
        reply_markup=get_main_keyboard(show_admin=is_admin(uid)),
        parse_mode="HTML"
    )

# ==================== 消息处理器 ====================
@dp.message(Command("start"))
async def cmd_start(message: types.Message):
    """开始命令 - 自动显示按钮"""
    uid = message.from_user.id
    await message.answer(
        config.MESSAGES["welcome"],
        reply_markup=get_main_keyboard(show_admin=is_admin(uid))
    )

@dp.message(Command("menu"))
async def cmd_menu(message: types.Message):
    """显示主菜单"""
    uid = message.from_user.id
    await message.answer("📋 主菜单", reply_markup=get_main_keyboard(show_admin=is_admin(uid)))

@dp.message(Command("admin"))
async def cmd_admin(message: types.Message):
    """管理员命令"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return
    await message.answer("👑 管理员面板", reply_markup=get_admin_keyboard())

#=======用户可以通过输入 /help 命令来查看所有可用的打卡和回座指令========

@dp.message(Command("help"))
async def cmd_help(message: types.Message):
    """帮助命令 - 显示用户可用指令"""
    uid = message.from_user.id
    
    help_text = (
        "📋 打卡机器人使用帮助\n\n"
        "🟢 开始活动打卡：\n"
        "• 直接输入活动名称（如：<code>吃饭</code>、<code>小厕</code>）\n"
        "• 或使用命令：<code>/ci 活动名</code>\n"
        "• 或点击下方活动按钮\n\n"
        "🔴 结束活动回座：\n"
        "• 直接输入：<code>回座</code>\n"
        "• 或使用命令：<code>/at</code>\n"
        "• 或点击下方 <code>✅ 回座</code> 按钮\n\n"
        "📊 查看记录：\n"
        "• 点击 <code>📊 我的记录</code> 查看个人统计\n"
        "• 点击 <code>🏆 排行榜</code> 查看群内排名\n\n"
        "🔧 其他命令：\n"
        "• <code>/start</code> - 开始使用机器人\n"
        "• <code>/menu</code> - 显示主菜单\n"
        "• <code>/help</code> - 显示此帮助信息\n\n"
        "⏰ 注意事项：\n"
        "• 每个活动有每日次数限制和时间限制\n"
        "• 超时会产生罚款\n"
        "• 活动完成后请及时回座\n"
        "• 每日数据会在指定时间自动重置"
    )
    
    await message.answer(
        help_text,
        reply_markup=get_main_keyboard(show_admin=is_admin(uid)),
        parse_mode="HTML"
    )

# ==================== 管理员命令功能 ====================
@dp.message(Command("setchannel"))
async def cmd_setchannel(message: types.Message):
    """绑定提醒频道"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return

    chat_id = message.chat.id
    args = message.text.split(maxsplit=1)

    if len(args) < 2:
        await message.answer(config.MESSAGES["setchannel_usage"], reply_markup=get_main_keyboard())
        return

    try:
        channel_id = int(args[1].strip())
        init_group(chat_id)
        group_data[str(chat_id)]["频道ID"] = channel_id
        await schedule_save_data()
        await message.answer(f"✅ 已绑定超时提醒推送频道：<code>{channel_id}</code>", reply_markup=get_main_keyboard(show_admin=True), parse_mode="HTML")
    except ValueError:
        await message.answer("❌ 频道ID必须是数字", reply_markup=get_main_keyboard(show_admin=True))

@dp.message(Command("setgroup"))
async def cmd_setgroup(message: types.Message):
    """绑定通知群组"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return

    chat_id = message.chat.id
    args = message.text.split(maxsplit=1)

    if len(args) < 2:
        await message.answer(config.MESSAGES["setgroup_usage"], reply_markup=get_main_keyboard())
        return

    try:
        group_id = int(args[1].strip())
        init_group(chat_id)
        group_data[str(chat_id)]["通知群组ID"] = group_id
        await schedule_save_data()

        await message.answer(f"✅ 已绑定超时通知群组：<code>{group_id}</code>", reply_markup=get_main_keyboard(show_admin=True), parse_mode="HTML")
    except ValueError:
        await message.answer("❌ 群组ID必须是数字", reply_markup=get_main_keyboard(show_admin=True))

@dp.message(Command(commands=["unbindchannel"]))
async def cmd_unbind_channel(message: types.Message, command: CommandObject = None):
    """解除绑定频道"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return
    chat_id = message.chat.id
    init_group(chat_id)
    group_data[str(chat_id)]["频道ID"] = None
    await schedule_save_data()

    await message.answer("✅ 已解除绑定的提醒频道", reply_markup=get_main_keyboard(show_admin=True))

@dp.message(Command(commands=["unbindgroup"]))
async def cmd_unbind_group(message: types.Message, command: CommandObject = None):
    """解除绑定通知群组"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return
    chat_id = message.chat.id
    init_group(chat_id)
    group_data[str(chat_id)]["通知群组ID"] = None
    await schedule_save_data()

    await message.answer("✅ 已解除绑定的通知群组", reply_markup=get_main_keyboard(show_admin=True))

@dp.message(Command("addactivity"))
async def cmd_addactivity(message: types.Message):
    """添加新活动或修改已有活动"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return

    args = message.text.split()
    if len(args) != 4:
        await message.answer(config.MESSAGES["addactivity_usage"], reply_markup=get_main_keyboard(show_admin=True))
        return

    try:
        act, max_times, time_limit = args[1], int(args[2]), int(args[3])
        existed = act in activity_limits
        activity_limits[act] = {"max_times": max_times, "time_limit": time_limit}
        # 若活动之前无罚款配置，使用默认最后一段或空
        if act not in fine_rates:
            fine_rates[act] = {}
        await schedule_save_data()

        if existed:
            await message.answer(f"✅ 已修改活动 <code>{act}</code>，次数上限 <code>{max_times}</code>，时间限制 <code>{time_limit}</code> 分钟", reply_markup=get_main_keyboard(show_admin=True), parse_mode="HTML")
        else:
            await message.answer(f"✅ 已添加新活动 <code>{act}</code>，次数上限 <code>{max_times}</code>，时间限制 <code>{time_limit}</code> 分钟", reply_markup=get_main_keyboard(show_admin=True), parse_mode="HTML")
    except Exception as e:
        await message.answer(f"❌ 添加/修改活动失败：{e}", reply_markup=get_main_keyboard(show_admin=True))

@dp.message(Command("delactivity"))
async def cmd_delactivity(message: types.Message):
    """删除活动"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return
    args = message.text.split()
    if len(args) != 2:
        await message.answer("❌ 用法：/delactivity <活动名>", reply_markup=get_main_keyboard(show_admin=True))
        return
    act = args[1]
    if act not in activity_limits:
        await message.answer(f"❌ 活动 <code>{act}</code> 不存在", reply_markup=get_main_keyboard(show_admin=True), parse_mode="HTML")
        return
    # 删除活动并保存
    activity_limits.pop(act, None)
    fine_rates.pop(act, None)
    await schedule_save_data()

    await message.answer(f"✅ 活动 <code>{act}</code> 已删除（按钮将随主键盘更新）", reply_markup=get_main_keyboard(show_admin=True), parse_mode="HTML")

@dp.message(Command("set"))
async def cmd_set(message: types.Message):
    """设置用户数据"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return

    args = message.text.split()
    if len(args) != 4:
        await message.answer(config.MESSAGES["set_usage"], reply_markup=get_main_keyboard(show_admin=True))
        return

    try:
        uid, act, minutes = args[1], args[2], args[3]
        chat_id = message.chat.id

        init_user(chat_id, int(uid))
        group_data[str(chat_id)]["成员"][str(uid)]["累计"][act] = int(minutes) * 60
        # 同时设置次数（只是估算）
        group_data[str(chat_id)]["成员"][str(uid)]["次数"][act] = int(minutes) // 30
        await schedule_save_data()


        await message.answer(f"✅ 已设置用户 <code>{uid}</code> 的 <code>{act}</code> 累计时间为 <code>{minutes}</code> 分钟", reply_markup=get_main_keyboard(show_admin=True), parse_mode="HTML")
    except Exception as e:
        await message.answer(f"❌ 设置失败：{e}", reply_markup=get_main_keyboard(show_admin=True))

@dp.message(Command("reset"))
async def cmd_reset(message: types.Message):
    """重置用户数据"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return

    args = message.text.split()
    if len(args) != 2:
        await message.answer(config.MESSAGES["reset_usage"], reply_markup=get_main_keyboard(show_admin=True))
        return

    try:
        uid = args[1]
        chat_id = message.chat.id

        init_user(chat_id, int(uid))
        group_data[str(chat_id)]["成员"][str(uid)]["累计"] = {}
        group_data[str(chat_id)]["成员"][str(uid)]["次数"] = {}
        group_data[str(chat_id)]["成员"][str(uid)]["总累计时间"] = 0
        group_data[str(chat_id)]["成员"][str(uid)]["总次数"] = 0
        group_data[str(chat_id)]["成员"][str(uid)]["累计罚款"] = 0
        await schedule_save_data()


        await message.answer(f"✅ 已重置用户 <code>{uid}</code> 的今日数据", reply_markup=get_main_keyboard(show_admin=True), parse_mode="HTML")
    except Exception as e:
        await message.answer(f"❌ 重置失败：{e}", reply_markup=get_main_keyboard(show_admin=True))

@dp.message(Command("setresettime"))
async def cmd_setresettime(message: types.Message):
    """设置每日重置时间"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return

    args = message.text.split()
    if len(args) != 3:
        await message.answer(config.MESSAGES["setresettime_usage"], reply_markup=get_main_keyboard(show_admin=True))
        return

    try:
        hour = int(args[1])
        minute = int(args[2])

        if 0 <= hour <= 23 and 0 <= minute <= 59:
            chat_id = message.chat.id
            init_group(chat_id)
            group_data[str(chat_id)]["每日重置时间"] = {"hour": hour, "minute": minute}
            await schedule_save_data()


            await message.answer(f"✅ 每日重置时间已设置为：<code>{hour:02d}:{minute:02d}</code>", reply_markup=get_main_keyboard(show_admin=True), parse_mode="HTML")
        else:
            await message.answer("❌ 小时必须在0-23之间，分钟必须在0-59之间！", reply_markup=get_main_keyboard(show_admin=True))
    except ValueError:
        await message.answer("❌ 请输入有效的数字！", reply_markup=get_main_keyboard(show_admin=True))

@dp.message(Command("setfine"))
async def cmd_setfine(message: types.Message):
    """设置活动罚款费率（单个活动）"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return

    args = message.text.split()
    if len(args) != 4:
        await message.answer(config.MESSAGES["setfine_usage"], reply_markup=get_main_keyboard(show_admin=True))
        return

    try:
        act = args[1]
        time_segment = args[2]
        fine_amount = int(args[3])

        if act not in activity_limits:
            await message.answer(f"❌ 活动 '<code>{act}</code>' 不存在！", reply_markup=get_main_keyboard(show_admin=True), parse_mode="HTML")
            return

        if fine_amount < 0:
            await message.answer("❌ 罚款金额不能为负数！", reply_markup=get_main_keyboard(show_admin=True))
            return

        if act not in fine_rates:
            fine_rates[act] = {}

        fine_rates[act][time_segment] = fine_amount
        await schedule_save_data()


        await message.answer(f"✅ 已设置活动 '<code>{act}</code>' 在 <code>{time_segment}</code> 分钟内的罚款费率为 <code>{fine_amount}</code> 元", reply_markup=get_main_keyboard(show_admin=True), parse_mode="HTML")
    except ValueError:
        await message.answer("❌ 请输入有效的数字！", reply_markup=get_main_keyboard(show_admin=True))
    except Exception as e:
        await message.answer(f"❌ 设置失败：{e}", reply_markup=get_main_keyboard(show_admin=True))

@dp.message(Command("setfines_all"))
async def cmd_setfines_all(message: types.Message):
    """
    为所有活动统一设置分段罚款
    用法示例： /setfines_all 10 100 30 300 60 1000
    表示：超时10分钟内罚款100，超时30分钟内罚款300，超时60分钟内罚款1000
    """
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return

    args = message.text.split()
    if len(args) < 3 or (len(args) - 1) % 2 != 0:
        await message.answer(config.MESSAGES["setfines_all_usage"], reply_markup=get_main_keyboard(show_admin=True))
        return

    try:
        pairs = args[1:]
        segments = {}
        for i in range(0, len(pairs), 2):
            t = int(pairs[i])
            f = int(pairs[i+1])
            if t <= 0 or f < 0:
                await message.answer("❌ 时间段必须为正整数，罚款金额不能为负数", reply_markup=get_main_keyboard(show_admin=True))
                return
            segments[str(t)] = f

        # 应用到所有活动（覆盖）
        for act in activity_limits.keys():
            fine_rates[act] = segments.copy()

        await schedule_save_data()

        segments_text = " ".join([f"<code>{t}</code>:<code>{f}</code>" for t, f in segments.items()])
        await message.answer(f"✅ 已为所有活动设置分段罚款：{segments_text}", reply_markup=get_main_keyboard(show_admin=True), parse_mode="HTML")
    except Exception as e:
        await message.answer(f"❌ 设置失败：{e}", reply_markup=get_main_keyboard(show_admin=True))

@dp.message(Command("showsettings"))
async def cmd_showsettings(message: types.Message):
    """显示目前的设置：包含绑定的频道群组、每日重置时间、活动设置等"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return
    chat_id = message.chat.id
    init_group(chat_id)
    cfg = group_data[str(chat_id)]

    text = f"🔧 当前群设置（群 {chat_id}）\n"
    text += f"• 绑定频道ID: {cfg.get('频道ID', '未设置')}\n"
    text += f"• 通知群组ID: {cfg.get('通知群组ID', '未设置')}\n"
    rt = cfg.get("每日重置时间", {"hour": config.DAILY_RESET_HOUR, "minute": config.DAILY_RESET_MINUTE})
    text += f"• 每日重置时间: {rt.get('hour',0):02d}:{rt.get('minute',0):02d}\n\n"

    text += "📋 活动设置：\n"
    for act, v in activity_limits.items():
        text += f"• {act}：次数上限 {v['max_times']}，时间限制 {v['time_limit']} 分钟\n"

    text += "\n💰 当前各活动罚款分段（若活动无独立设置则显示为空或默认）：\n"
    for act, fr in fine_rates.items():
        text += f"• {act}：{fr}\n"

    await message.answer(text, reply_markup=get_main_keyboard(show_admin=True), parse_mode="HTML")

# ==================== 推送开关管理命令 ====================
@dp.message(Command("setpush"))
async def cmd_setpush(message: types.Message):
    """设置推送开关"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return

    args = message.text.split()
    if len(args) != 3:
        await message.answer(config.MESSAGES["setpush_usage"], reply_markup=get_main_keyboard(show_admin=True))
        return

    push_type = args[1].lower()
    status = args[2].lower()

    if push_type not in ["channel", "group", "admin"]:
        await message.answer("❌ 类型错误，请使用 channel、group 或 admin", reply_markup=get_main_keyboard(show_admin=True))
        return

    if status not in ["on", "off"]:
        await message.answer("❌ 状态错误，请使用 on 或 off", reply_markup=get_main_keyboard(show_admin=True))
        return

    # 更新设置
    if push_type == "channel":
        config.AUTO_EXPORT_SETTINGS["enable_channel_push"] = (status == "on")
        status_text = "开启" if status == "on" else "关闭"
        await message.answer(f"✅ 已{status_text}频道推送", reply_markup=get_main_keyboard(show_admin=True))
    elif push_type == "group":
        config.AUTO_EXPORT_SETTINGS["enable_group_push"] = (status == "on")
        status_text = "开启" if status == "on" else "关闭"
        await message.answer(f"✅ 已{status_text}群组推送", reply_markup=get_main_keyboard(show_admin=True))
    elif push_type == "admin":
        config.AUTO_EXPORT_SETTINGS["enable_admin_push"] = (status == "on")
        status_text = "开启" if status == "on" else "关闭"
        await message.answer(f"✅ 已{status_text}管理员推送", reply_markup=get_main_keyboard(show_admin=True))

    # 保存设置到文件
    save_push_settings()

@dp.message(Command("showpush"))
async def cmd_showpush(message: types.Message):
    """显示推送设置"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return

    settings = config.AUTO_EXPORT_SETTINGS
    text = (
        "🔔 当前自动导出推送设置：\n\n"
        f"📢 频道推送：{'✅ 开启' if settings['enable_channel_push'] else '❌ 关闭'}\n"
        f"👥 群组推送：{'✅ 开启' if settings['enable_group_push'] else '❌ 关闭'}\n"
        f"👑 管理员推送：{'✅ 开启' if settings['enable_admin_push'] else '❌ 关闭'}\n\n"
        "💡 使用说明：\n"
        "• 频道推送：推送到绑定的频道\n"
        "• 群组推送：推送到绑定的通知群组\n"
        "• 管理员推送：当没有绑定群组/频道时推送到所有管理员\n\n"
        "⚙️ 修改命令：\n"
        "<code>/setpush channel on|off</code>\n"
        "<code>/setpush group on|off</code>\n"
        "<code>/setpush admin on|off</code>"
    )
    await message.answer(text, reply_markup=get_main_keyboard(show_admin=True), parse_mode="HTML")

@dp.message(Command("testpush"))
async def cmd_testpush(message: types.Message):
    """测试推送功能"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return

    chat_id = message.chat.id
    try:
        # 创建一个测试文件
        test_file_name = f"test_push_{datetime.now().strftime('%H%M%S')}.txt"
        with open(test_file_name, "w", encoding="utf-8") as f:
            f.write("这是一个推送测试文件\n")
            f.write(f"测试时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("如果收到此文件，说明推送功能正常")

        caption = "🧪 推送功能测试\n这是一个测试文件，用于验证自动导出推送功能是否正常工作。"

        success_count = 0
        
        # 测试群组推送
        if config.AUTO_EXPORT_SETTINGS["enable_group_push"]:
            notification_group_id = group_data.get(str(chat_id), {}).get("通知群组ID")
            if notification_group_id:
                try:
                    await bot.send_document(
                        notification_group_id,
                        FSInputFile(test_file_name),
                        caption=caption,
                        parse_mode="HTML"
                    )
                    success_count += 1
                    await message.answer(f"✅ 测试文件已发送到通知群组: {notification_group_id}")
                except Exception as e:
                    await message.answer(f"❌ 通知群组推送测试失败: {e}")

        # 测试频道推送
        if config.AUTO_EXPORT_SETTINGS["enable_channel_push"]:
            channel_id = group_data.get(str(chat_id), {}).get("频道ID")
            if channel_id:
                try:
                    await bot.send_document(
                        channel_id,
                        FSInputFile(test_file_name),
                        caption=caption,
                        parse_mode="HTML"
                    )
                    success_count += 1
                    await message.answer(f"✅ 测试文件已发送到频道: {channel_id}")
                except Exception as e:
                    await message.answer(f"❌ 频道推送测试失败: {e}")

        # 清理测试文件
        os.remove(test_file_name)

        if success_count == 0:
            await message.answer("⚠️ 没有成功发送任何测试推送，请检查推送设置和绑定状态")
        else:
            await message.answer(f"✅ 推送测试完成，成功发送 {success_count} 个测试文件")

    except Exception as e:
        await message.answer(f"❌ 推送测试失败：{e}")

# ==================== 新增导出数据命令 ====================
@dp.message(Command("export"))
async def cmd_export(message: types.Message):
    """导出数据命令"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return
    await export_data(message)

# ==================== 简化版指令：保留 /ci 和 /at 作为备用 ====================
@dp.message(Command("ci"))
async def cmd_ci(message: types.Message):
    """指令打卡：/ci 活动名（备用）"""
    args = message.text.split(maxsplit=1)
    if len(args) != 2:
        await message.answer("❌ 用法：/ci <活动名>", reply_markup=get_main_keyboard(show_admin=is_admin(message.from_user.id)))
        return
    act = args[1].strip()
    if act not in activity_limits:
        await message.answer(f"❌ 活动 '<code>{act}</code>' 不存在，请先使用 /addactivity 添加或检查拼写", reply_markup=get_main_keyboard(show_admin=is_admin(message.from_user.id)), parse_mode="HTML")
        return
    await start_activity(message, act)

@dp.message(Command("at"))
async def cmd_at(message: types.Message):
    """指令回座：/at（备用）"""
    await process_back(message)

# ============ 文本命令处理（支持直接输入活动名称和回座） =================
@dp.message(lambda message: message.text and message.text.strip() in ["回座", "✅ 回座"])
async def handle_back_command(message: types.Message):
    """处理直接输入'回座'命令或点击回座按钮"""
    await process_back(message)

@dp.message(lambda message: message.text and message.text.strip() in ["📊 我的记录"])
async def handle_my_record(message: types.Message):
    """处理我的记录按钮"""
    await show_history(message)

@dp.message(lambda message: message.text and message.text.strip() in ["🏆 排行榜"])
async def handle_rank(message: types.Message):
    """处理排行榜按钮"""
    await show_rank(message)

@dp.message(lambda message: message.text and message.text.strip() in ["👑 管理员面板"])
async def handle_admin_panel_button(message: types.Message):
    """处理管理员面板按钮点击"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return

    admin_text = (
        "👑 管理员面板\n\n"
        "可用命令：\n"
        "• /setchannel <频道ID> - 绑定提醒频道\n"
        "• /setgroup <群组ID> - 绑定通知群组\n"
        "• /unbindchannel - 解除绑定频道\n"
        "• /unbindgroup - 解除绑定通知群组\n"
        "• /addactivity <活动名> <次数> <分钟> - 添加或修改活动\n"
        "• /delactivity <活动名> - 删除活动\n"
        "• /set <用户ID> <活动> <分钟> - 设置用户时间\n"
        "• /reset <用户ID> - 重置用户数据\n"
        "• /setresettime <小时> <分钟> - 设置每日重置时间\n"
        "• /setfine <活动名> <时间段> <金额> - 设置活动罚款费率\n"
        "• /setfines_all <t1> <f1> [<t2> <f2> ...] - 为所有活动统一设置分段罚款\n"
        "• /showsettings - 查看当前群设置\n"
        "• /export - 导出数据\n\n"
        "点击下方按钮进行操作："
    )
    await message.answer(admin_text, reply_markup=get_admin_keyboard())

@dp.message(lambda message: message.text and message.text.strip() in ["🔙 返回主菜单"])
async def handle_back_to_main_menu(message: types.Message):
    """处理返回主菜单按钮"""
    uid = message.from_user.id
    await message.answer("已返回主菜单", reply_markup=get_main_keyboard(show_admin=is_admin(uid)))

@dp.message(lambda message: message.text and message.text.strip() in ["📤 导出数据"])
async def handle_export_data_button(message: types.Message):
    """处理导出数据按钮点击"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return
    await export_data(message)

@dp.message(lambda message: message.text and message.text.strip() in activity_limits.keys())
async def handle_activity_direct_input(message: types.Message):
    """处理直接输入活动名称进行打卡"""
    act = message.text.strip()
    await start_activity(message, act)

@dp.message(lambda message: message.text and message.text.strip())
async def handle_other_text_messages(message: types.Message):
    """处理其他文本消息 - 显示提示"""
    text = message.text.strip()
    uid = message.from_user.id
    
    # 排除已知的命令和特定文本
    if (text.startswith("/") or 
        text in ["👑 管理员面板", "🔙 返回主菜单", "📤 导出数据", "🔔 通知设置"]):
        return
    
    # 检查是否是活动相关消息（应该已经被上面的处理器处理）
    if any(act in text for act in activity_limits.keys()):
        return
    
    # 如果是空消息或者未知文本，显示提示
    await message.answer(
        "请使用下方按钮或直接输入活动名称进行操作：\n\n"
        "📝 使用方法：\n"
        "• 输入活动名称（如：<code>吃饭</code>、<code>小厕</code>）开始打卡\n"
        "• 输入'回座'或点击'✅ 回座'按钮结束当前活动\n"
        "• 点击'📊 我的记录'查看个人统计\n"
        "• 点击'🏆 排行榜'查看群内排名",
        reply_markup=get_main_keyboard(show_admin=is_admin(uid)),
        parse_mode="HTML"
    )

# ==================== 用户功能 ====================
async def show_history(message: types.Message):
    """显示用户历史记录"""
    chat_id = message.chat.id
    uid = message.from_user.id
    init_user(chat_id, uid)
    await reset_daily_data(chat_id, uid) 

    user = group_data[str(chat_id)]["成员"][str(uid)]
    first_line = f"👤 用户：{format_user_link(uid, user['昵称'])}"
    text = f"{first_line}\n📊 今日记录：\n\n"

    has_records = False
    for act in activity_limits.keys():
        total_time = user["累计"].get(act, 0)
        count = user["次数"].get(act, 0)
        max_times = activity_limits[act]["max_times"]
        if total_time > 0 or count > 0:
            status = "✅" if count < max_times else "❌"
            time_str = format_time(int(total_time))
            text += f"• <code>{act}</code>：<code>{time_str}</code>，次数：<code>{count}</code>/<code>{max_times}</code> {status}\n"
            has_records = True

    total_time_all = user.get("总累计时间", 0)
    total_count_all = user.get("总次数", 0)
    total_fine = user.get("累计罚款", 0)

    text += f"\n📈 今日总统计：\n"
    text += f"• 总累计时间：<code>{format_time(int(total_time_all))}</code>\n"
    text += f"• 总活动次数：<code>{total_count_all}</code> 次\n"
    if total_fine > 0:
        text += f"• 累计罚款：<code>{total_fine}</code> 元"

    if not has_records and total_count_all == 0:
        text += "暂无记录，请先进行打卡活动"

    await message.answer(text, reply_markup=get_main_keyboard(show_admin=is_admin(uid)), parse_mode="HTML")

async def show_rank(message: types.Message):
    """显示排行榜"""
    chat_id = message.chat.id
    uid = message.from_user.id
    init_group(chat_id)

    rank_text = "🏆 今日活动排行榜\n\n"

    for act in activity_limits.keys():
        user_times = []
        for user_uid, user_data in group_data[str(chat_id)]["成员"].items():
            total_time = user_data["累计"].get(act, 0)
            if total_time > 0:
                user_times.append((user_data['昵称'], user_data['用户ID'], total_time))

        user_times.sort(key=lambda x: x[2], reverse=True)
        if user_times:
            rank_text += f"📈 <code>{act}</code>：\n"
            for i, (name, user_id, time_sec) in enumerate(user_times[:3], 1):
                time_str = format_time(int(time_sec))
                rank_text += f"  <code>{i}.</code> {format_user_link(user_id, name)} - <code>{time_str}</code>\n"
            rank_text += "\n"

    await message.answer(rank_text, reply_markup=get_main_keyboard(show_admin=is_admin(uid)), parse_mode="HTML")

# ==================== 回座功能 ====================
async def process_back(message: types.Message):
    """回座打卡 - 按照指定格式显示"""
    chat_id = message.chat.id
    uid = message.from_user.id
    now = datetime.now()

    init_user(chat_id, uid)
    await reset_daily_data(chat_id, uid)  # ✅ 添加 await

    user_data = group_data[str(chat_id)]["成员"][str(uid)]
    if not user_data["活动"]:
        await message.answer(config.MESSAGES["no_activity"], reply_markup=get_main_keyboard(show_admin=is_admin(uid)))
        return

    act = user_data["活动"]
    start_time = datetime.fromisoformat(user_data["开始时间"])
    elapsed = (now - start_time).total_seconds()
    total_activity_time = user_data["累计"].get(act, 0) + elapsed

    # 检查是否超时
    time_limit_seconds = activity_limits[act]["time_limit"] * 60
    is_overtime = elapsed > time_limit_seconds
    overtime_seconds = max(0, int(elapsed - time_limit_seconds))

    # 计算罚款（分段罚款）
    fine_amount = 0
    if is_overtime and overtime_seconds > 0:
        overtime_minutes = overtime_seconds / 60
        fine_amount = calculate_fine(act, overtime_minutes)
        user_data["累计罚款"] = user_data.get("累计罚款", 0) + fine_amount

    # 更新用户数据
    user_data["累计"][act] = total_activity_time
    current_count = user_data["次数"].get(act, 0)
    user_data["总累计时间"] = user_data.get("总累计时间", 0) + elapsed
    user_data["总次数"] = user_data.get("总次数", 0) + 1
    user_data["活动"] = None
    user_data["开始时间"] = None
    await schedule_save_data()


    # 取消定时任务
    key = f"{chat_id}-{uid}"
    if key in tasks and not tasks[key].done():
        tasks[key].cancel()

    # 构建活动次数字典
    activity_counts = {a: user_data["次数"].get(a, 0) for a in activity_limits.keys()}

    # 发送回座消息
    await message.answer(
        format_back_message(
            user_id=uid,
            user_name=user_data['昵称'],
            activity=act,
            time_str=now.strftime('%m/%d %H:%M:%S'),
            elapsed_time=format_time(int(elapsed)),
            total_activity_time=format_time(int(total_activity_time)),
            total_time=format_time(int(user_data["总累计时间"])),
            activity_counts=activity_counts,
            total_count=user_data["总次数"],
            is_overtime=is_overtime,
            overtime_seconds=overtime_seconds,
            fine_amount=fine_amount
        ),
        reply_markup=get_main_keyboard(show_admin=is_admin(uid)),
        parse_mode="HTML"
    )

    # ✅ 如果超时，推送通知到绑定群组和频道（只在回座时推送）
    if is_overtime:
        try:
            chat_title = str(chat_id)
            try:
                chat_info = await bot.get_chat(chat_id)
                chat_title = chat_info.title or chat_title
            except Exception as e:
                logging.warning(f"无法获取群组信息: {e}")

            overtime_seconds = max(1, int(overtime_seconds))  # 避免0秒不推送
            notif_text = (
                f"🚨 <b>超时回座通知</b>\n"
                f"🏢 群组：<code>{chat_title}</code>\n"
                f"--------------------------------------------\n"
                f"👤 用户：{format_user_link(uid, user_data['昵称'])}\n"
                f"📝 活动：<code>{act}</code>\n"
                f"⏰ 回座时间：<code>{now.strftime('%m/%d %H:%M:%S')}</code>\n"
                f"⏱️ 超时时长：<code>{format_time(int(overtime_seconds))}</code>\n"
                f"💰 本次罚款：<code>{fine_amount}</code> 元"
            )

            sent = False
            # 频道推送
            channel_id = group_data.get(str(chat_id), {}).get("频道ID")
            if config.AUTO_EXPORT_SETTINGS.get("enable_channel_push") and channel_id:
                try:
                    await bot.send_message(channel_id, notif_text, parse_mode="HTML")
                    sent = True
                    logging.info(f"✅ 已推送超时信息至频道 {channel_id}")
                except Exception as e:
                    logging.error(f"❌ 推送至频道失败: {e}")

            # 通知群组推送
            group_id = group_data.get(str(chat_id), {}).get("通知群组ID")
            if config.AUTO_EXPORT_SETTINGS.get("enable_group_push") and group_id:
                try:
                    await bot.send_message(group_id, notif_text, parse_mode="HTML")
                    sent = True
                    logging.info(f"✅ 已推送超时信息至通知群组 {group_id}")
                except Exception as e:
                    logging.error(f"❌ 推送至通知群组失败: {e}")

            # 管理员兜底推送
            if not sent and config.AUTO_EXPORT_SETTINGS.get("enable_admin_push"):
                for admin_id in config.ADMINS:
                    try:
                        await bot.send_message(admin_id, f"⚠️ 超时通知未能推送到群组/频道：\n\n{notif_text}", parse_mode="HTML")
                        logging.info(f"✅ 已转发超时通知给管理员 {admin_id}")
                    except Exception as e:
                        logging.error(f"❌ 管理员推送失败: {e}")

        except Exception as e:
            logging.error(f"⚠️ 超时通知推送异常: {e}")


# ==================== 管理员按钮处理 ====================
@dp.message(lambda message: message.text == "🔔 通知设置")
async def handle_notification_settings(message: types.Message, state: FSMContext):
    """处理通知设置按钮"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return
    await notification_settings_menu(message, state)

# ==================== 通知设置功能 ====================
async def notification_settings_menu(message: types.Message, state: FSMContext):
    """通知设置菜单"""
    chat_id = message.chat.id
    init_group(chat_id)
    group_config = group_data[str(chat_id)]

    current_settings = (
        f"🔔 当前通知设置：\n"
        f"频道ID: <code>{group_config.get('频道ID', '未设置')}</code>\n"
        f"通知群组ID: <code>{group_config.get('通知群组ID', '未设置')}</code>\n\n"
        f"请选择操作："
    )

    keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="设置频道"), KeyboardButton(text="设置通知群组")],
            [KeyboardButton(text="清除频道"), KeyboardButton(text="清除通知群组")],
            [KeyboardButton(text="🔙 返回管理员面板")]
        ],
        resize_keyboard=True
    )

    await message.answer(current_settings, reply_markup=keyboard, parse_mode="HTML")

@dp.message(lambda message: message.text in ["设置频道", "设置通知群组", "清除频道", "清除通知群组", "🔙 返回管理员面板"])
async def handle_notification_actions(message: types.Message, state: FSMContext):
    """处理通知设置操作"""
    text = message.text
    chat_id = message.chat.id

    if text == "🔙 返回管理员面板":
        await state.clear()
        await message.answer("已返回管理员面板", reply_markup=get_admin_keyboard())
        return
    elif text == "设置频道":
        await message.answer("请输入频道ID（格式如 -1001234567890）：", reply_markup=ReplyKeyboardRemove())
        await state.set_state(AdminStates.waiting_for_channel_id)
    elif text == "设置通知群组":
        await message.answer("请输入通知群组ID（格式如 -1001234567890）：", reply_markup=ReplyKeyboardRemove())
        await state.set_state(AdminStates.waiting_for_group_id)
    elif text == "清除频道":
        init_group(chat_id)
        group_data[str(chat_id)]["频道ID"] = None
        await schedule_save_data()

        await message.answer("✅ 已清除频道设置", reply_markup=get_admin_keyboard())
    elif text == "清除通知群组":
        init_group(chat_id)
        group_data[str(chat_id)]["通知群组ID"] = None
        await schedule_save_data()

        await message.answer("✅ 已清除通知群组设置", reply_markup=get_admin_keyboard())

@dp.message(AdminStates.waiting_for_channel_id)
async def set_channel_id(message: types.Message, state: FSMContext):
    """设置频道ID"""
    try:
        channel_id = int(message.text)
        chat_id = message.chat.id
        init_group(chat_id)
        group_data[str(chat_id)]["频道ID"] = channel_id
        await schedule_save_data()
        await message.answer(f"✅ 已绑定提醒频道：<code>{channel_id}</code>", reply_markup=get_admin_keyboard(), parse_mode="HTML")
        await state.clear()
    except ValueError:
        await message.answer("❌ 请输入有效的频道ID！")

@dp.message(AdminStates.waiting_for_group_id)
async def set_group_id(message: types.Message, state: FSMContext):
    """设置通知群组ID"""
    try:
        group_id = int(message.text)
        chat_id = message.chat.id
        init_group(chat_id)
        group_data[str(chat_id)]["通知群组ID"] = group_id
        await schedule_save_data()
        await message.answer(f"✅ 已绑定通知群组：<code>{group_id}</code>", reply_markup=get_admin_keyboard(), parse_mode="HTML")
        await state.clear()
    except ValueError:
        await message.answer("❌ 请输入有效的群组ID！")

# ==================== 管理员数据功能 ====================
async def export_data(message: types.Message):
    """导出数据 - 按照新格式：每个用户一行，包含所有活动的总计"""
    chat_id = message.chat.id
    file_name = f"group_{chat_id}_statistics.csv"

    try:
        with open(file_name, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            
            # 构建表头：用户基本信息 + 每个活动的次数和时长 + 总计信息
            headers = ["用户ID", "用户昵称"]
            
            # 为每个活动添加次数和时长列
            for act in activity_limits.keys():
                headers.append(f"{act}次数")
                headers.append(f"{act}总时长")
            
            # 添加总计列
            headers.extend(["活动次数总计", "活动用时总计", "罚款总金额"])
            
            writer.writerow(headers)
            
            # 写入每个用户的数据
            for uid, user_data in group_data[str(chat_id)]["成员"].items():
                user_id = uid
                user_nickname = user_data.get("昵称", "未知用户")
                
                # 构建用户数据行
                user_row = [user_id, user_nickname]
                
                # 为每个活动添加次数和时长数据
                for act in activity_limits.keys():
                    activity_count = user_data["次数"].get(act, 0)
                    activity_time = user_data["累计"].get(act, 0)
                    
                    user_row.append(activity_count)
                    user_row.append(format_time_for_export(int(activity_time)))
                
                # 添加总计信息
                total_count = user_data.get("总次数", 0)
                total_time = user_data.get("总累计时间", 0)
                total_fine = user_data.get("累计罚款", 0)
                
                user_row.extend([
                    total_count,
                    format_time_for_export(int(total_time)),
                    total_fine
                ])
                
                writer.writerow(user_row)

        # 使用 FSInputFile 发送文件
        await message.answer_document(FSInputFile(file_name), reply_markup=get_admin_keyboard())
        # 删除临时文件
        os.remove(file_name)
    except Exception as e:
        await message.answer(f"❌ 导出失败：{e}", reply_markup=get_admin_keyboard())

# ==================== 系统维护功能 ====================
async def export_data_before_reset(chat_id: int):
    """在重置前自动导出CSV数据并推送到绑定的群组和频道 - 使用新格式"""
    try:
        # 生成带日期的文件名
        date_str = datetime.now().strftime('%Y%m%d')
        file_name = f"group_{chat_id}_statistics_{date_str}.csv"

        with open(file_name, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            
            # 构建表头：用户基本信息 + 每个活动的次数和时长 + 总计信息
            headers = ["用户ID", "用户昵称"]
            
            # 为每个活动添加次数和时长列
            for act in activity_limits.keys():
                headers.append(f"{act}次数")
                headers.append(f"{act}总时长")
            
            # 添加总计列
            headers.extend(["活动次数总计", "活动用时总计", "罚款总金额"])
            
            writer.writerow(headers)
            
            # 写入每个用户的数据
            for uid, user_data in group_data[str(chat_id)]["成员"].items():
                user_id = uid
                user_nickname = user_data.get("昵称", "未知用户")
                
                # 构建用户数据行
                user_row = [user_id, user_nickname]
                
                # 为每个活动添加次数和时长数据
                for act in activity_limits.keys():
                    activity_count = user_data["次数"].get(act, 0)
                    activity_time = user_data["累计"].get(act, 0)
                    
                    user_row.append(activity_count)
                    user_row.append(format_time_for_export(int(activity_time)))
                
                # 添加总计信息
                total_count = user_data.get("总次数", 0)
                total_time = user_data.get("总累计时间", 0)
                total_fine = user_data.get("累计罚款", 0)
                
                user_row.extend([
                    total_count,
                    format_time_for_export(int(total_time)),
                    total_fine
                ])
                
                writer.writerow(user_row)

        # 检查是否有数据需要导出
        has_data = False
        for uid, user_data in group_data[str(chat_id)]["成员"].items():
            if user_data.get("总次数", 0) > 0:
                has_data = True
                break

        if not has_data:
            print(f"⚠️ 群组 {chat_id} 没有数据需要导出")
            if os.path.exists(file_name):
                os.remove(file_name)
            return

        print(f"✅ 群组 {chat_id} 的每日数据已自动导出到 {file_name}")

        # 获取群组名称用于消息标题
        chat_title = str(chat_id)
        try:
            chat_info = await bot.get_chat(chat_id)
            chat_title = chat_info.title or chat_title
        except:
            pass

        # 准备消息文本
        caption = (
            f"📊 每日数据备份报告\n"
            f"🏢 群组：<code>{chat_title}</code>\n"
            f"📅 日期：<code>{datetime.now().strftime('%Y-%m-%d')}</code>\n"
            f"⏰ 导出时间：<code>{datetime.now().strftime('%H:%M:%S')}</code>\n"
            f"--------------------------------------------\n"
            f"💾 数据已重置，此文件为重置前的完整记录\n"
            f"📈 包含每个用户的所有活动统计和总计信息"
        )

        success_sent = False

        # 1. 发送到绑定的通知群组（如果启用）
        if config.AUTO_EXPORT_SETTINGS["enable_group_push"]:
            notification_group_id = group_data.get(str(chat_id), {}).get("通知群组ID")
            if notification_group_id:
                try:
                    await bot.send_document(
                        notification_group_id,
                        FSInputFile(file_name),
                        caption=caption,
                        parse_mode="HTML"
                    )
                    print(f"✅ 已发送到通知群组: {notification_group_id}")
                    success_sent = True
                except Exception as e:
                    print(f"❌ 发送到通知群组失败: {e}")

        # 2. 发送到绑定的频道（如果启用）
        if config.AUTO_EXPORT_SETTINGS["enable_channel_push"]:
            channel_id = group_data.get(str(chat_id), {}).get("频道ID")
            if channel_id:
                try:
                    await bot.send_document(
                        channel_id,
                        FSInputFile(file_name),
                        caption=caption,
                        parse_mode="HTML"
                    )
                    print(f"✅ 已发送到频道: {channel_id}")
                    success_sent = True
                except Exception as e:
                    print(f"❌ 发送到频道失败: {e}")

        # 3. 如果没有绑定群组或频道，发送给所有管理员（如果启用）
        if not success_sent and config.AUTO_EXPORT_SETTINGS["enable_admin_push"]:
            print("⚠️ 未设置群组或频道，尝试发送给管理员")
            for admin_id in config.ADMINS:
                try:
                    await bot.send_document(
                        admin_id,
                        FSInputFile(file_name),
                        caption=f"📊 群组 {chat_title} 的每日数据备份\n日期: {date_str}",
                        parse_mode="HTML"
                    )
                    print(f"✅ 已发送给管理员: {admin_id}")
                except Exception as e:
                    print(f"❌ 发送给管理员 {admin_id} 失败: {e}")

        # 删除临时文件
        os.remove(file_name)
        
    except Exception as e:
        print(f"❌ 自动导出数据失败：{e}")

async def daily_reset_task():
    """每日自动重置任务 - 支持自定义重置时间，并在重置时自动导出CSV"""
    while True:
        now = datetime.now()

        # 为每个群组计算下一次重置时间
        earliest_reset = None

        for chat_id_str, chat_data in group_data.items():
            reset_time = chat_data.get("每日重置时间", {"hour": config.DAILY_RESET_HOUR, "minute": config.DAILY_RESET_MINUTE})
            reset_hour = reset_time["hour"]
            reset_minute = reset_time["minute"]

            next_reset = datetime.combine(now.date(), datetime.min.time()) + timedelta(hours=reset_hour, minutes=reset_minute)
            if next_reset <= now:
                next_reset += timedelta(days=1)

            if earliest_reset is None or next_reset < earliest_reset:
                earliest_reset = next_reset

        if earliest_reset is None:
            earliest_reset = datetime.combine(now.date() + timedelta(days=1), datetime.min.time())

        wait_seconds = (earliest_reset - now).total_seconds()
        print(f"下一次重置将在 {earliest_reset} 执行，等待 {wait_seconds} 秒")

        await asyncio.sleep(wait_seconds)

        now_after_wait = datetime.now()
        for chat_id_str, chat_data in group_data.items():
            reset_time = chat_data.get("每日重置时间", {"hour": config.DAILY_RESET_HOUR, "minute": config.DAILY_RESET_MINUTE})
            reset_hour = reset_time["hour"]
            reset_minute = reset_time["minute"]

            expected_reset = datetime.combine(now_after_wait.date(), datetime.min.time()) + timedelta(hours=reset_hour, minutes=reset_minute)
            if now_after_wait >= expected_reset:
                # 在重置前先导出数据
                await export_data_before_reset(int(chat_id_str))
                
                # 然后执行重置
                for user_data in chat_data["成员"].values():
                    user_data["累计"] = {}
                    user_data["次数"] = {}
                    user_data["总累计时间"] = 0
                    user_data["总次数"] = 0
                    user_data["累计罚款"] = 0
                    user_data["最后更新"] = str(now_after_wait.date())

                print(f"{now_after_wait}: 群组 {chat_id_str} 数据重置完成")

        await schedule_save_data()

# ==================== 新增导入/启动流程 ====================
if __name__ == "__main__":
    logging.info("🚀 群打卡机器人启动中...")
    load_data()
    load_push_settings()
    logging.info("✅ 数据加载完毕，开始监听 Telegram...")
    asyncio.run(dp.start_polling(bot))
